from django.db import models

# Create your models here.
class Question(models.Model):
    q_id = models.AutoField(primary_key=True)
    q_no = models.IntegerField(default=0)
    question = models.CharField(max_length=500)
    a1 = models.CharField(max_length=200)
    a2 = models.CharField(max_length=200)
    a3 = models.CharField(max_length=200)
    a4 = models.CharField(max_length=200)
    c = models.IntegerField()

