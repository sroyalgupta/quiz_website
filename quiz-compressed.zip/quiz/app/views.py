from django.shortcuts import render
from django.http import HttpResponse
from .models import Question
from random import randint
# Create your views here.

def index(request):
    all = Question.objects.all()
    temp = randint(1,len(all))
    question = Question.objects.filter(q_no=temp)
    print(question)
    params= {'questions':question}
    return render(request,'app/index.html',params)
